===========================
 Confirm POS action by PIN
===========================

Installation
============

 * `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Configuration
=============

* Go to ``[[Settings]] >> Users >> Users``

  * Open user form
  * Click ``[Edit]``
  * Navigate to `Point of Sale`` tab
  * Set PIN
  * Click ``[Save]``

Usage
=====

* Go to ``[[Point of Sale]] >> Dashboard``
  
  * Open POS session
  * Change the user using switcher at the top left corner
  * Input PIN

RESULT: If the PIN is correct, the user is switched successfully
