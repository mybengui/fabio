`1.2.2`
-------

- **Fix:** Id of undefined error appeared when a pin was entered correctly

`1.2.1`
-------

- **Fix:** Cannot set property of undefined on some actions with password popup

`1.2.0`
-------

- **NEW:** Ability not to change cashier after entering pin

`1.1.0`
-------

- **NEW:** New password pop-up functionality

`1.0.0`
-------

- Init version
