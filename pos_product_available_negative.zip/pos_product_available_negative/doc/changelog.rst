`1.1.1`
-------

- **Fix:** Cashier was changed after giving the authorization of the sale

`1.1.0`
-------

- **Fix:** Cashier was changed after giving the authorization of the sale
- **New:** Added option 'Ask Managers Permission to proceed order with negative stock products'
- **New:** Added option 'Show Warning on adding out of stock products'

`1.0.1`
-------

- **FIX:** Compatibility with pos_product_available after it was updated

`1.0.0`
-------

- Init version
